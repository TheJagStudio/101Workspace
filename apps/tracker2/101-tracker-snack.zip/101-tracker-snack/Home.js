import React, { useState, useEffect, useRef } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  FlatList,
  Keyboard,
  Platform,
  StyleSheet,
  SafeAreaView,
  Dimensions,
} from 'react-native';
import {
  MapPin,
  Search,
  Battery,
  Wifi,
  WifiOff,
  Play,
  Square,
  Route,
  CheckCircle,
  Clock,
} from 'lucide-react-native';
import { apiRequest } from './utils/api';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { useNavigation } from '@react-navigation/native';
import MapView, { Marker } from 'react-native-maps';
import MapViewDirections from 'react-native-maps-directions';
import * as Location from 'expo-location';
import {
  registerBackgroundTaskAsync,
  unregisterBackgroundTaskAsync,
  isTaskRegistered,
} from './App';

const Home = () => {
  const [isTracking, setIsTracking] = useState(false);
  const [isRegistered, setIsRegistered] = useState(false);
  const [battery, setBattery] = useState(100);
  const [signal, setSignal] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState([]);
  const [alerts, setAlerts] = useState([]);
  const [routeHistory, setRouteHistory] = useState([]);
  const [todaysActivity, setTodaysActivity] = useState(null);
  const [todaysPlannedRoute, setTodaysPlannedRoute] = useState(null);
  const navigation = useNavigation();
  // const clearStorage = async () => {
  //     await AsyncStorage.clear();
  //     console.log("AsyncStorage cleared");
  // };
  // clearStorage();
  useEffect(() => {
    const checkUser = async () => {
      const accessToken = await AsyncStorage.getItem('accessToken');
      const refreshToken = await AsyncStorage.getItem('refreshToken');
      if (!accessToken || !refreshToken) {
        navigation.replace('login');
      }
    };
    checkUser();
  }, [navigation]);
  async function handleRegisterTask() {
    // 1. Request permissions
    const { status: foregroundStatus } =
      await Location.requestForegroundPermissionsAsync();
    if (foregroundStatus !== 'granted') {
      setAlerts((prev) => [
        ...prev,
        {
          type: 'error',
          message:
            'Foreground location access is needed to track your location.',
        },
      ]);
      return;
    }

    const { status: backgroundStatus } =
      await Location.requestBackgroundPermissionsAsync();
    if (backgroundStatus !== 'granted') {
      setAlerts((prev) => [
        ...prev,
        {
          type: 'error',
          message:
            'Background location access is needed for the app to work when closed.',
        },
      ]);
      return;
    }

    setPermissionsGranted(true);

    // 2. Register the task
    await registerBackgroundTaskAsync();
    setIsRegistered(true);
    setAlerts((prev) => [
      ...prev,
      {
        type: 'success',
        message: 'Your location will now be updated every 3 minutes.',
      },
    ]);
  }

  async function handleUnregisterTask() {
    await unregisterBackgroundTaskAsync();
    setIsRegistered(false);
    setAlerts((prev) => [
      ...prev,
      {
        type: 'success',
        message: 'Your location will no longer be tracked.',
      },
    ]);
  }
  useEffect(() => {
    apiRequest(`http://10.1.11.205:8000/api/tracker/salesman/activity/today/`)
      .then((response) => {
        setTodaysActivity(response);
        setIsTracking(response?.is_tracking || false);
        if (response?.is_tracking) {
          handleRegisterTask();
        } else {
          handleUnregisterTask();
        }
      })
      .catch((err) => {
        if (err.name === 'AuthError') {
          navigation.replace('login');
        } else {
          if (err.status !== 404) {
            setAlerts((prev) => [
              ...prev,
              {
                type: 'error',
                message: err.message || 'An unexpected error occurred.',
              },
            ]);
          }
        }
      });

    apiRequest(
      `http://10.1.11.205:8000/api/tracker/salesman/planned_routes/today/`
    )
      .then((response) => {
        setTodaysPlannedRoute(response);
      })
      .catch((err) => {
        if (err.status !== 404) {
          setAlerts((prev) => [
            ...prev,
            { type: 'info', message: "There isn't any planned route today" },
          ]);
        }
      });
  }, []);

  useEffect(() => {
    if (alerts.length > 0) {
      const timeoutId = setTimeout(() => {
        setAlerts((prev) => prev.slice(1));
      }, 2000);
      return () => clearTimeout(timeoutId);
    }
  }, [alerts]);

  const handleSearch = () => {
    if (!searchQuery.trim()) return;
    apiRequest(
      `http://10.1.11.205:8000/api/tracker/salesman/places_search/?query=${encodeURIComponent(
        searchQuery
      )}`
    )
      .then((data) => {
        if (data.status === 'OK') {
          setSearchResults(
            data?.results?.map((place) => ({
              id: place?.place_id,
              name: place?.name,
              address: place?.formatted_address,
              lat: place?.geometry.location.lat,
              lng: place?.geometry.location.lng,
            }))
          );
        } else {
          setSearchResults([]);
        }
      })
      .catch((err) => {
        setAlerts((prev) => [
          ...prev,
          { type: 'error', message: 'Failed to search places.' },
        ]);
        setSearchResults([]);
      });
    Keyboard.dismiss();
  };

  const handleAddToRoute = (place, isBulk = false) => {
    const payload = {
      location_name: place?.name,
      address: place?.address,
      latitude: place?.lat,
      longitude: place?.lng,
    };
    apiRequest(
      `http://10.1.11.205:8000/api/tracker/salesman/planned_routes/add_stop/`,
      {
        method: 'POST',
        body: JSON.stringify(payload),
      }
    )
      .then(() => {
        if (!isBulk) {
          setAlerts((prev) => [
            ...prev,
            {
              type: 'success',
              message: `Added "${place?.name}" to your route!`,
            },
          ]);
        }
        return apiRequest(
          `http://10.1.11.205:8000/api/tracker/salesman/planned_routes/today/`
        );
      })
      .then((response) => {
        setTodaysPlannedRoute(response);
      })
      .catch((err) => {
        setAlerts((prev) => [
          ...prev,
          {
            type: 'error',
            message: `Failed to add "${place?.name}" to route.`,
          },
        ]);
      });
    if (!routeHistory.some((entry) => entry.id === place.id)) {
      const newHistory = [
        ...routeHistory,
        { id: place.id, addedAt: new Date().toISOString() },
      ];
      setRouteHistory(newHistory);
    }
  };

  const handleAddAll = () => {
    searchResults.forEach((place) => handleAddToRoute(place, true));
    setSearchResults([]);
    setAlerts((prev) => [
      ...prev,
      { type: 'success', message: 'Added all search results to your route!' },
    ]);
  };

  const handleClearSearch = () => {
    setSearchResults([]);
  };

  const handleToggleTracking = async () => {
    const newTrackingStatus = !isTracking;
    try {
      await apiRequest(
        `http://10.1.11.205:8000/api/tracker/salesman/set_tracking_status/`,
        {
          method: 'POST',
          body: JSON.stringify({
            status: newTrackingStatus ? 'active' : 'offline',
          }),
        }
      );
      setIsTracking(newTrackingStatus);
      setAlerts((prev) => [
        ...prev,
        {
          type: newTrackingStatus ? 'success' : 'error',
          message: newTrackingStatus
            ? 'Tracking started.'
            : 'Tracking stopped.',
        },
      ]);
    } catch (error) {
      setAlerts((prev) => [
        ...prev,
        { type: 'error', message: 'Could not update tracking status.' },
      ]);
    }
  };

  const removeAlert = (idx) => {
    setAlerts((prev) => prev.filter((_, i) => i !== idx));
  };

  const plannedRouteMarkers = React.useMemo(() => {
    if (!todaysPlannedRoute?.stops || !Array.isArray(todaysPlannedRoute.stops))
      return [];
    return todaysPlannedRoute.stops.map((stop, idx) => ({
      id: stop.id?.toString() || idx.toString(),
      title: stop.location_name || `Stop ${idx + 1}`,
      description: stop.address || '',
      coordinate: {
        latitude: stop.latitude,
        longitude: stop.longitude,
      },
    }));
  }, [todaysPlannedRoute]);

  const routePoints = React.useMemo(() => {
    if (!todaysPlannedRoute?.stops || todaysPlannedRoute.stops.length < 2)
      return null;
    const stops = todaysPlannedRoute.stops;
    const origin = {
      latitude: stops[0].latitude,
      longitude: stops[0].longitude,
    };
    const destination = {
      latitude: stops[stops.length - 1].latitude,
      longitude: stops[stops.length - 1].longitude,
    };
    const waypoints = stops
      .slice(1, -1)
      .map((stop) => ({ latitude: stop.latitude, longitude: stop.longitude }));
    return { origin, destination, waypoints };
  }, [todaysPlannedRoute]);

  const initialRegion =
    plannedRouteMarkers.length > 0
      ? {
          latitude: plannedRouteMarkers[0].coordinate.latitude,
          longitude: plannedRouteMarkers[0].coordinate.longitude,
          latitudeDelta: 0.05,
          longitudeDelta: 0.05,
        }
      : {
          latitude: 37.78825,
          longitude: -122.4324,
          latitudeDelta: 0.05,
          longitudeDelta: 0.05,
        };

  return (
    <SafeAreaView style={styles.safeArea}>
      <View style={styles.container}>
        <View style={styles.searchBarContainer}>
          <TextInput
            style={styles.searchInput}
            placeholder="e.g., gas station near stone mountain"
            value={searchQuery}
            onChangeText={setSearchQuery}
            onSubmitEditing={handleSearch}
            returnKeyType="search"
            placeholderTextColor="#6b7280"
          />
          <TouchableOpacity style={styles.searchButton} onPress={handleSearch}>
            <Search size={20} color="#fff" />
          </TouchableOpacity>
        </View>

        {searchResults.length > 0 && (
          <View style={styles.searchResultsContainer}>
            <FlatList
              data={searchResults}
              keyExtractor={(item) => item?.id}
              renderItem={({ item }) => (
                <View style={styles.searchResultItem}>
                  <View style={styles.searchResultInfo}>
                    <Text style={styles.searchResultName}>{item?.name}</Text>
                    <Text style={styles.searchResultAddress} numberOfLines={1}>
                      {item?.address}
                    </Text>
                  </View>
                  {!routeHistory.some((entry) => entry.id === item?.id) && (
                    <TouchableOpacity
                      onPress={() => handleAddToRoute(item, false)}>
                      <Text style={styles.addButtonText}>Add</Text>
                    </TouchableOpacity>
                  )}
                </View>
              )}
            />
            <View style={styles.searchResultsFooter}>
              <TouchableOpacity
                style={styles.footerButton}
                onPress={handleAddAll}>
                <Text style={styles.footerButtonText}>Add All</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={styles.footerButton}
                onPress={handleClearSearch}>
                <Text style={styles.footerButtonText}>Clear</Text>
              </TouchableOpacity>
            </View>
          </View>
        )}

        <View style={styles.statusIndicatorsContainer}>
          <View style={styles.statusIndicator}>
            <Text
              style={[
                styles.statusText,
                { color: isTracking ? '#16a34a' : '#ef4444' },
              ]}>
              {isTracking ? 'Active' : 'Inactive'}
            </Text>
            <Text style={styles.statusLabel}>Tracking Status</Text>
          </View>
          <View style={styles.statusIndicator}>
            <View style={styles.batteryIndicator}>
              <Battery size={20} color={battery < 20 ? '#ef4444' : '#22c55e'} />
              <Text style={styles.statusText}>{battery}%</Text>
            </View>
            <Text style={styles.statusLabel}>Battery</Text>
          </View>
          <View style={styles.statusIndicator}>
            <Text>
              {signal ? (
                <Wifi size={20} color="#22c55e" />
              ) : (
                <WifiOff size={20} color="#ef4444" />
              )}
            </Text>
            <Text style={styles.statusLabel}>Signal</Text>
          </View>
        </View>

        <TouchableOpacity
          style={[
            styles.trackingButton,
            { backgroundColor: isTracking ? '#ef4444' : '#22c55e' },
          ]}
          onPress={handleToggleTracking}>
          {isTracking ? (
            <Square size={24} color="#fff" />
          ) : (
            <Play size={24} color="#fff" />
          )}
          <Text style={styles.trackingButtonText}>
            {isTracking ? 'Stop Tracking' : 'Start Tracking'}
          </Text>
        </TouchableOpacity>

        <View style={styles.mapContainer}>
          {plannedRouteMarkers.length > 0 ? (
            <MapView
              style={StyleSheet.absoluteFill}
              region={initialRegion}
              provider="google">
              {plannedRouteMarkers.map((marker) => (
                <Marker
                  key={marker.id}
                  coordinate={marker.coordinate}
                  title={marker.title}
                  description={marker.description}
                />
              ))}
              <MapViewDirections
                origin={plannedRouteMarkers[0].coordinate}
                destination={
                  plannedRouteMarkers[plannedRouteMarkers.length - 1].coordinate
                }
                apikey={'AIzaSyBxBKKw8qRbooHIASvS0gkhiGa4EIr8pA4'}
                strokeWidth={4}
                strokeColor="orange"
                precision="high"
                timePrecision="now"
                optimizeWaypoints={true}
                waypoints={plannedRouteMarkers.map(
                  (marker) => marker.coordinate
                )}
              />
            </MapView>
          ) : (
            <View style={styles.noMapDataContainer}>
              <Text style={styles.noMapDataText}>
                No planned route stops to display on map.
              </Text>
            </View>
          )}
        </View>

        <View style={styles.activityContainer}>
          <Text style={styles.activityTitle}>Today's Activity</Text>
          {todaysActivity ? (
            <View style={styles.activityMetricsContainer}>
              <View style={styles.activityMetric}>
                <CheckCircle size={18} color="#3b82f6" />
                <View style={styles.metricInfo}>
                  <Text style={styles.metricValue}>
                    {todaysActivity.checkpoints}
                  </Text>
                  <Text style={styles.metricLabel}>Check points</Text>
                </View>
              </View>
              <View style={styles.activityMetric}>
                <Route size={18} color="#a21caf" />
                <View style={styles.metricInfo}>
                  <Text style={styles.metricValue}>
                    {todaysActivity.distance?.toFixed(1)} km
                  </Text>
                  <Text style={styles.metricLabel}>Distance</Text>
                </View>
              </View>
              <View style={styles.activityMetric}>
                <Clock size={18} color="#22c55e" />
                <View style={styles.metricInfo}>
                  <Text style={styles.metricValue}>
                    {todaysActivity.duration || '0m'}
                  </Text>
                  <Text style={styles.metricLabel}>Duration</Text>
                </View>
              </View>
            </View>
          ) : (
            <Text style={styles.noActivityText}>
              No activity recorded yet today.
            </Text>
          )}
        </View>
      </View>

      <View style={styles.alertsContainer}>
        {alerts.map((alert, idx) => (
          <View
            key={idx}
            style={[
              styles.alert,
              alert?.type === 'error' ? styles.alertError : styles.alertSuccess,
            ]}>
            <View style={styles.alertTextContainer}>
              <Text
                style={
                  alert?.type === 'error'
                    ? styles.alertErrorText
                    : styles.alertSuccessText
                }>
                {alert?.message}
              </Text>
            </View>
            <TouchableOpacity
              onPress={() => removeAlert(idx)}
              style={styles.alertCloseButton}
              hitSlop={10}>
              <Text
                style={[
                  styles.alertCloseButtonText,
                  alert?.type === 'error'
                    ? styles.alertErrorText
                    : styles.alertSuccessText,
                ]}>
                ×
              </Text>
            </TouchableOpacity>
          </View>
        ))}
      </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: '#f3f4f6',
  },
  container: {
    flex: 1,
    padding: 16,
  },
  searchBarContainer: {
    flexDirection: 'row',
    backgroundColor: '#fff',
    borderRadius: 12,
    alignItems: 'center',
    padding: 8,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#d1d5db',
  },
  searchInput: {
    flex: 1,
    height: 40,
    padding: 8,
    fontSize: 16,
    color: '#111827',
  },
  searchButton: {
    padding: 8,
    backgroundColor: '#f97316',
    borderRadius: 6,
    marginLeft: 8,
  },
  searchResultsContainer: {
    backgroundColor: '#fff',
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#d1d5db',
    marginBottom: 12,
    paddingTop: 4,
    maxHeight: 224,
  },
  searchResultItem: {
    flexDirection: 'row',
    width: '100%',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 8,
    paddingHorizontal: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#e5e7eb',
  },
  searchResultInfo: {
    flex: 1,
    marginRight: 8,
  },
  searchResultName: {
    fontWeight: 'bold',
    fontSize: 16,
  },
  searchResultAddress: {
    fontSize: 12,
    color: '#6b7280',
    width: '90%', // To prevent text from pushing the "Add" button out
  },
  addButtonText: {
    color: '#ea580c',
    fontWeight: 'bold',
    fontSize: 14,
  },
  searchResultsFooter: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    backgroundColor: '#e5e7eb',
    padding: 8,
    borderBottomLeftRadius: 12,
    borderBottomRightRadius: 12,
  },
  footerButton: {
    backgroundColor: '#fff',
    paddingVertical: 4,
    paddingHorizontal: 12,
    borderRadius: 4,
    borderWidth: 1,
    borderColor: '#d1d5db',
  },
  footerButtonText: {
    color: '#374151',
    fontWeight: '600',
  },
  statusIndicatorsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 16,
    marginTop: 8,
  },
  statusIndicator: {
    alignItems: 'center',
    flex: 1,
  },
  statusText: {
    fontWeight: 'bold',
    fontSize: 18,
    color: '#1f2937',
  },
  statusLabel: {
    fontSize: 12,
    color: '#6b7280',
    marginTop: 2,
  },
  batteryIndicator: {
    flexDirection: 'row',
    gap: 8,
    alignItems: 'center',
    justifyContent: 'center',
  },
  trackingButton: {
    width: '100%',
    paddingVertical: 16,
    borderRadius: 8,
    alignItems: 'center',
    marginBottom: 16,
    flexDirection: 'row',
    justifyContent: 'center',
  },
  trackingButtonText: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 18,
    marginLeft: 8,
  },
  mapContainer: {
    marginBottom: 16,
    borderRadius: 12,
    overflow: 'hidden',
    backgroundColor: '#fff',
    borderWidth: 1,
    borderColor: '#e5e7eb',
    height: 260,
  },
  noMapDataContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  noMapDataText: {
    color: '#9ca3af',
  },
  activityContainer: {
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 16,
    marginBottom: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.2,
    shadowRadius: 1.41,
    elevation: 2,
  },
  activityTitle: {
    fontWeight: 'bold',
    color: '#1f2937',
    marginBottom: 12,
    fontSize: 16,
  },
  activityMetricsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    gap: 8,
  },
  activityMetric: {
    flexDirection: 'row',
    flex: 1,
    alignItems: 'center',
    justifyContent: 'flex-start',
    backgroundColor: '#f9fafb',
    padding: 8,
    borderRadius: 8,
    borderLeftWidth: 1,
    borderBottomWidth: 1,
    borderColor: '#d1d5db',
  },
  metricInfo: {
    marginLeft: 8,
  },
  metricValue: {
    fontWeight: 'bold',
    fontSize: 16,
  },
  metricLabel: {
    fontSize: 12,
    color: '#6b7280',
  },
  noActivityText: {
    fontSize: 12,
    color: '#6b7280',
  },
  alertsContainer: {
    position: 'absolute',
    left: 0,
    right: 0,
    alignItems: 'center',
    bottom: Platform.OS === 'ios' ? 48 : 24,
    zIndex: 50,
    pointerEvents: 'box-none',
  },
  alert: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    minWidth: 300,
    maxWidth: '90%',
    paddingVertical: 4,
    paddingHorizontal: 16,
    borderRadius: 12,
    borderLeftWidth: 4,
    marginBottom: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.23,
    shadowRadius: 2.62,
    elevation: 4,
  },
  alertError: {
    backgroundColor: 'rgba(254, 226, 226, 0.8)',
    borderColor: '#ef4444',
  },
  alertSuccess: {
    backgroundColor: 'rgba(220, 252, 231, 0.8)',
    borderColor: '#22c55e',
  },
  alertTextContainer: {
    flex: 1,
  },
  alertErrorText: {
    color: '#b91c1c',
  },
  alertSuccessText: {
    color: '#15803d',
  },
  alertCloseButton: {
    backgroundColor: 'transparent',
    marginLeft: 10,
    paddingHorizontal: 6,
  },
  alertCloseButtonText: {
    fontSize: 22,
    lineHeight: 24,
  },
});

export default Home;
